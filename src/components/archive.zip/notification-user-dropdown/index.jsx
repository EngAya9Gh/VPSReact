import PropTypes from 'prop-types';
import Image from 'next/image';
import Anchor from '@ui/anchor';
import LogoutButton from '@components/logout-button';
import axios from 'axios';

const UserDropdown = ({ ethBalance, notifications }) => {
  return (
    <div className="icon-box">
      <Anchor path="/">
        <Image
          src="/images/icons/boy-avater.png"
          alt="Images"
          width={38}
          height={38}
        />
      </Anchor>
      <div className="rn-dropdown">
        <ul className="list-inner">
          {/* عرض الإشعارات في القائمة */}
          {notifications && notifications.length > 0 ? (
            notifications.map((notification, index) => (
              <li key={index}>
                <p>{notification.message}</p> 
                <small>({notification.created_at})</small> 
              </li>
            ))
          ) : (
            <li>لايوجد اشعارات</li>  
          )}
        </ul>
      </div>
    </div>
  );
};

UserDropdown.propTypes = {
  ethBalance: PropTypes.string,
  notifications: PropTypes.arrayOf(
    PropTypes.shape({
      message: PropTypes.string.isRequired,
      created_at: PropTypes.string.isRequired,
    })
  ).isRequired,
  auth: PropTypes.shape({
    first_name: PropTypes.string,
    last_name: PropTypes.string,
    name: PropTypes.string,
    email: PropTypes.string,
    password: PropTypes.string,
  }),
};

export default UserDropdown;
